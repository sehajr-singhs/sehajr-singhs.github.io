import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
v = json.load(open("../results/verify_search.json"))
plt.rcParams.update({"font.size": 11})
fig, (a, b) = plt.subplots(1, 2, figsize=(10.5, 3.8))
labels = ["training tuples\n(random u)", "closed loop u=π(x)\nwhole region X", "closed loop u=π(x)\nnear equilibrium"]
vals = [0.0, 100 * v["dense_full"]["F_D"]["frac_violated"], 100 * v["dense_scale_0.01"]["F_D"]["frac_violated"]]
bars = a.bar(labels, vals, color=["#2f5d8a", "#b3482f", "#b3482f"])
for r, x in zip(bars, vals):
    a.text(r.get_x() + r.get_width() / 2, x + 2, f"{x:.0f}%", ha="center")
a.set_ylim(0, 110); a.set_ylabel("points violating the\ndissipativity inequality")
a.set_title("Same learned inequality, two places it is checked", fontsize=10)
lab2 = ["whole region X", "box at 5% of X", "box at 1% of X"]
vals2 = [100 * v["dense_full"]["F_L"]["frac_violated"], 100 * v["dense_scale_0.05"]["F_L"]["frac_violated"], 100 * v["dense_scale_0.01"]["F_L"]["frac_violated"]]
bars = b.bar(lab2, vals2, color="#8a8a85")
for r, x in zip(bars, vals2):
    b.text(r.get_x() + r.get_width() / 2, x + 2, f"{x:.0f}%", ha="center")
b.set_ylim(0, 110); b.set_ylabel("points where V(x+) > V(x)")
b.set_title("Closed-loop Lyapunov decrease, dense sample", fontsize=10)
for ax in (a, b):
    for k in ("top", "right"):
        ax.spines[k].set_visible(False)
fig.tight_layout(); fig.savefig("../figures/kundur_verification.png", dpi=200); print("ok")
