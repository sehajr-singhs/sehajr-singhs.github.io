"""Train the dissipativity-based neural controller of Wang et al. (arXiv:2510.22324) on the rebuilt
all-VSG Kundur model. Matrix networks W(x) (storage), Q(x) (symmetric), S(x), R^{-1}(x) (positive definite),
control pi(x) = -R^{-1}(x) S(x)^T x. Losses follow the paper: dissipativity (eq. 12), stability condition
Phi = S R^{-1} S^T - Q > 0 (eq. 13), cost shaping (eq. 14, our reading), L1 regularization.
Deviations from the paper (dataset size, epsilons, cost-shaping form) are written to results/train_config.json.
Usage: python train.py [n_traj] [epochs]
"""
import json, os, sys, time
import numpy as np
import torch
import torch.nn as nn
import kundur as K

torch.manual_seed(0)
N, M_IN = 7, 4
N_TRAJ = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
EPOCHS = int(sys.argv[2]) if len(sys.argv) > 2 else 20
EPS_D = EPS_PHI = EPS_SP = 1e-3
U_MAX = 0.3
SCALE = torch.tensor([K.DD_LIM] * 3 + [K.DW_LIM] * 4, dtype=torch.float32)


def mlp(out):
    return nn.Sequential(nn.Linear(N, 128), nn.GELU(), nn.Linear(128, 128), nn.GELU(), nn.Linear(128, out))


def tril_to_pd(v, n, eps=1e-3):
    L = torch.zeros(v.shape[0], n, n)
    idx = torch.tril_indices(n, n)
    L[:, idx[0], idx[1]] = v
    d = torch.arange(n)
    L[:, d, d] = nn.functional.softplus(L[:, d, d]) + eps
    return L @ L.transpose(1, 2) + eps * torch.eye(n)


class Controller(nn.Module):
    def __init__(self):
        super().__init__()
        self.W = mlp(N * (N + 1) // 2)
        self.Q = mlp(N * N)
        self.S = mlp(N * M_IN)
        self.Ri = mlp(M_IN * (M_IN + 1) // 2)

    def mats(self, x):
        z = x / SCALE
        W = tril_to_pd(self.W(z), N)
        Q = self.Q(z).view(-1, N, N)
        Q = 0.5 * (Q + Q.transpose(1, 2))
        S = self.S(z).view(-1, N, M_IN)
        Ri = tril_to_pd(self.Ri(z), M_IN)
        return W, Q, S, Ri

    def pi(self, x):
        W, Q, S, Ri = self.mats(x)
        return -(Ri @ S.transpose(1, 2) @ x.unsqueeze(-1)).squeeze(-1)

    def V(self, x):
        W = self.mats(x)[0]
        return (x.unsqueeze(1) @ W @ x.unsqueeze(-1)).squeeze(-1).squeeze(-1)


def quad(x, A, y=None):
    y = x if y is None else y
    return (x.unsqueeze(1) @ A @ y.unsqueeze(-1)).squeeze(-1).squeeze(-1)


def losses(net, x, xn, u):
    W, Q, S, Ri = net.mats(x)
    R = torch.linalg.inv(Ri)
    Vx = quad(x, W)
    Vn = net.V(xn)
    s = quad(x, Q) + 2 * quad(x, S, u) + quad(u, R)
    viol_d = nn.functional.softplus(EPS_D + Vn - Vx - s)
    L_d = viol_d.mean() + 0.1 * viol_d.max()
    Phi = S @ Ri @ S.transpose(1, 2) - Q
    lam = torch.linalg.eigvalsh(Phi)[:, 0]
    viol_p = nn.functional.softplus(EPS_PHI - lam)
    L_phi = viol_p.mean() + 0.1 * viol_p.max()
    pu = net.pi(x)
    s_pi = quad(x, Q) + 2 * quad(x, S, pu) + quad(pu, R)
    cost = 1000 * (x[:, 3:] ** 2).sum(1) + (x[:, :3] ** 2).sum(1) + 10 * (pu ** 2).sum(1)
    L_sp = nn.functional.softplus(EPS_SP + s_pi + cost).mean()
    L_r = sum(p.abs().sum() for p in net.parameters())
    # Theorem 2 needs pi(x) inside the trained input range U = [-u_max, u_max]^4
    L_u = nn.functional.softplus(20 * (pu.abs() - U_MAX)).mean() / 20
    return L_d, L_phi, L_sp, L_r, L_u


if __name__ == "__main__":
    os.makedirs("../results", exist_ok=True)
    t0 = time.time()
    if os.path.exists("../results/dataset.npy") and N_TRAJ == 2500:
        D = np.load("../results/dataset.npy"); d_star, pref, _ = K.post_pref()
    else:
        D, d_star, pref = K.gen_dataset(n_traj=N_TRAJ, length_s=1.0, u_max=0.3, seed=0, stride=10)
        np.save("../results/dataset.npy", D)
    print(f"dataset {D.shape} in {time.time() - t0:.0f}s", flush=True)
    X = torch.tensor(D[:, :N]); XN = torch.tensor(D[:, N:2 * N]); U = torch.tensor(D[:, 2 * N:])
    net = Controller()
    opt = torch.optim.Adam(net.parameters(), lr=1e-3, weight_decay=1e-4)
    w = (1.0, 1.0, 0.01, 1e-3 / sum(p.numel() for p in net.parameters()), 10.0)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, EPOCHS)
    bs = 2048
    hist = []
    for ep in range(EPOCHS):
        perm = torch.randperm(len(X))
        for i in range(0, len(X), bs):
            b = perm[i:i + bs]
            L = losses(net, X[b], XN[b], U[b])
            loss = sum(wi * li for wi, li in zip(w, L))
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 10.0); opt.step()
        sched.step()
        with torch.no_grad():
            sub = torch.randperm(len(X))[:20000]
            L = [float(l) for l in losses(net, X[sub], XN[sub], U[sub])]
        hist.append({"epoch": ep, "L_d": L[0], "L_phi": L[1], "L_sp": L[2], "L_r": L[3], "L_u": L[4], "t": time.time() - t0})
        print(hist[-1], flush=True)
    torch.save(net.state_dict(), "../results/controller.pt")
    json.dump({"n_traj": N_TRAJ, "stride": 10, "n_tuples": int(len(X)), "epochs": EPOCHS, "eps_d": EPS_D,
               "eps_phi": EPS_PHI, "eps_sp": EPS_SP, "batch": bs, "lr": 1e-3, "weight_decay": 1e-4,
               "loss_weights": "(1, 1, 0.01, 1e-3 per-parameter-normalized L1, 10 input-range); L_d and L_phi aggregated as mean + 0.1*max (paper: max)", "u_max": 0.3,
               "cost_shaping_reading": "softplus(eps + s(x,pi(x)) + l(x,pi(x))) averaged, with l = 1000|dw|^2 + |dd|^2 + 10|u|^2",
               "M_pu": K.M_PU, "D_pu": K.D_PU, "pref": [float(p) for p in pref], "history": hist},
              open("../results/train_config.json", "w"), indent=2)
    print("saved", time.time() - t0)
