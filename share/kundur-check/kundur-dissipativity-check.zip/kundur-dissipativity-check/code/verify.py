"""Check the learned dissipativity conditions over the whole operating region, not only at training samples.

Conditions (functions of the state x only, with u = pi(x)):
  F_L(x) = V(x) - V(x+)                        closed-loop Lyapunov decrease, must be >= 0
  F_D(x) = -x' Phi(x) x - (V(x+) - V(x)) - eps  dissipativity inequality (eq. 12) along u = pi(x), >= 0
           (s(x, pi(x)) = x'Qx - x' S R^{-1} S' x = -x' Phi x, so no matrix inverse is needed)
  F_P(x) = lambda_min(Phi(x))                   stability condition (eq. 13), must be > 0
  R:      |pi_i(x)| <= u_max                     Theorem 2 input-range hypothesis
Three tiers, never blurred:
  1. dense uniform sample of the region (a search, not a certificate)
  2. multi-start PGD minimising each F (a search, not a certificate); every counterexample re-checked
  3. CROWN (auto_LiRPA) with input-space branch-and-bound on boxes near the equilibrium (sound certificate)
Usage: python verify.py [n_dense] [pgd_starts]
"""
import json, sys, time
import numpy as np
import torch
import torch.nn as nn
import kundur as K
from train import Controller, U_MAX, EPS_D

torch.set_default_dtype(torch.float32)
N_DENSE = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
N_PGD = int(sys.argv[2]) if len(sys.argv) > 2 else 512

Yr = K.reduced_y("post")
d_star, pref, _ = K.post_pref()
E = torch.tensor(K.E_MAG, dtype=torch.float32)
G = torch.tensor(Yr.real, dtype=torch.float32)
B = torch.tensor(Yr.imag, dtype=torch.float32)
DSTAR = torch.tensor(d_star, dtype=torch.float32)
PREF = torch.tensor(pref, dtype=torch.float32)
LIM = torch.tensor([K.DD_LIM] * 3 + [K.DW_LIM] * 4)

net = Controller()
net.load_state_dict(torch.load("../results/controller.pt"))
net.eval()


def pe(d):  # d: (b,4) absolute angles
    dd = d.unsqueeze(2) - d.unsqueeze(1)            # (b,4,4) delta_i - delta_j
    EE = E.unsqueeze(1) * E.unsqueeze(0)
    return (EE * (G * torch.cos(dd) + B * torch.sin(dd))).sum(2)


def step(x, u, nsub=4):
    """One ZOH step of the swing model in relative coordinates (same RK4 as kundur.f_one_step_np)."""
    d = torch.cat([torch.zeros_like(x[:, :1]), x[:, :3]], 1) + DSTAR
    w = x[:, 3:] + 1.0
    h = K.DT / nsub

    def f(d, w):
        return K.WB * (w - 1.0), (PREF - pe(d) - K.D_PU * (w - 1.0) + u) / K.M_PU
    for _ in range(nsub):
        k1d, k1w = f(d, w)
        k2d, k2w = f(d + 0.5 * h * k1d, w + 0.5 * h * k1w)
        k3d, k3w = f(d + 0.5 * h * k2d, w + 0.5 * h * k2w)
        k4d, k4w = f(d + h * k3d, w + h * k3w)
        d = d + h / 6 * (k1d + 2 * k2d + 2 * k3d + k4d)
        w = w + h / 6 * (k1w + 2 * k2w + 2 * k3w + k4w)
    return torch.cat([d[:, 1:] - DSTAR[1:], w - 1.0], 1)


def conditions(x):
    W, Q, S, Ri = net.mats(x)
    u = -(Ri @ S.transpose(1, 2) @ x.unsqueeze(-1)).squeeze(-1)
    xn = step(x, u)
    Vx = (x.unsqueeze(1) @ W @ x.unsqueeze(-1)).flatten()
    Vn = net.V(xn)
    Phi = S @ Ri @ S.transpose(1, 2) - Q
    xPx = (x.unsqueeze(1) @ Phi @ x.unsqueeze(-1)).flatten()
    FL = Vx - Vn
    FD = -xPx - (Vn - Vx) - EPS_D
    FP = torch.linalg.eigvalsh(Phi)[:, 0]
    FR = U_MAX - u.abs().max(1).values
    return {"F_L": FL, "F_D": FD, "F_P": FP, "F_R": FR}


def uniform(n, scale=1.0):
    return (torch.rand(n, 7) * 2 - 1) * LIM * scale


def dense(n, scale=1.0, excl=0.0):
    out = {k: [] for k in ("F_L", "F_D", "F_P", "F_R")}
    pts = []
    with torch.no_grad():
        for i in range(0, n, 20000):
            x = uniform(min(20000, n - i), scale)
            if excl > 0:
                keep = (x.abs() / LIM).max(1).values >= excl * scale
                x = x[keep]
            c = conditions(x)
            for k in out:
                out[k].append(c[k])
            pts.append(x)
    X = torch.cat(pts)
    r = {}
    for k in out:
        v = torch.cat(out[k])
        r[k] = {"min": float(v.min()), "frac_violated": float((v < 0).float().mean()), "n": int(len(v)),
                "worst_x_over_limits": (X[v.argmin()] / LIM).tolist()}
    return r


def pgd(key, starts, scale=1.0, steps=200, excl=0.0):
    x = uniform(starts, scale).requires_grad_(True)
    opt = torch.optim.Adam([x], lr=0.01 * scale)
    for _ in range(steps):
        v = conditions(x)[key]
        opt.zero_grad(); v.sum().backward(); opt.step()
        with torch.no_grad():
            lim = LIM * scale
            x.data = torch.max(torch.min(x.data, lim), -lim)
            if excl > 0:  # stay outside the excluded neighbourhood of the equilibrium
                r = (x.data.abs() / lim).max(1, keepdim=True).values
                x.data = torch.where(r < excl, x.data * (excl / r.clamp_min(1e-9)), x.data)
    with torch.no_grad():
        v = conditions(x.detach())[key]
        xd = x.detach().double()
    i = int(v.argmin())
    return {"min": float(v.min()), "frac_starts_violated": float((v < 0).float().mean()),
            "worst_x_over_limits": (x.detach()[i] / LIM).tolist()}


if __name__ == "__main__":
    t0 = time.time()
    res = {"region_full": "|d_delta| <= 2*pi rad, |d_omega| <= 0.1 pu (paper's training region X)"}
    res["dense_full"] = dense(N_DENSE)
    print("dense full", {k: (round(v["min"], 5), round(v["frac_violated"], 4)) for k, v in res["dense_full"].items()}, flush=True)
    res["pgd_full"] = {k: pgd(k, N_PGD) for k in ("F_L", "F_D", "F_P", "F_R")}
    print("pgd full", {k: (round(v["min"], 5), round(v["frac_starts_violated"], 3)) for k, v in res["pgd_full"].items()}, flush=True)
    for sc in (0.05, 0.01):
        res[f"dense_scale_{sc}"] = dense(N_DENSE // 4, sc, excl=0.05)
        res[f"pgd_scale_{sc}"] = {k: pgd(k, N_PGD // 2, sc, excl=0.05) for k in ("F_L", "F_D", "F_P", "F_R")}
        print("scale", sc, {k: (round(v["min"], 6), round(v["frac_violated"], 4)) for k, v in res[f"dense_scale_{sc}"].items()}, flush=True)
    res["seconds"] = time.time() - t0
    json.dump(res, open("../results/verify_search.json", "w"), indent=2)
    print("saved", res["seconds"])
