"""All-VSG Kundur two-area system, rebuilt from Wang et al. (arXiv:2510.22324).

Everything in per-unit quantities on a 100 MVA / 230 kV base.
State (paper Section IV): x = [d2, d3, d4, dw1, dw2, dw3, dw4], where d_i is the
voltage angle of VSG i relative to VSG 1 measured against the post-fault
equilibrium, dw_i = omega_i - 1. Input u in R^4 is the per-VSG frequency-
adjustment control added to the swing equation. n = 7, m = 4.

Continuous dynamics (paper eq. 1), per VSG i:
    M d(omega_i)/dt = Pref_i - Pe_i(delta) - D (omega_i - 1) + u_i
    d(delta_i)/dt   = omega_B (omega_i - 1)
with Pe_i in the paper's exact closed form from the reduced admittance matrix:
    Pe_i = E_i^2 G_ii + sum_{j != i} E_i E_j (G_ij cos(d_ij) + B_ij sin(d_ij)).

Construction of the operating points (this file):
  * Every VSG is a constant virtual EMF E_i<delta_i behind the virtual
    impedance jXV; XV, D and the virtual inertia follow the paper
    (Section V-B): XV = 0.3 pu on the system 100 MVA base, D = 5 pu, H = 4 s
    ⇒ M_i = 2 H S_rated / (omega_B S_base) with S_rated = 900 MVA (the rating
    of the Kundur machines the VSGs replace) ⇒ M = 0.19098 pu*s.
  * The 15-node network (11 AC buses + 4 EMF nodes) is solved as a full AC
    power flow with Newton/least-squares. Because the virtual reactance is
    lossless, Pe at the EMF equals the injected P at the VSG bus, so the
    published Kundur power set points (7.00, 7.00, 7.19, 7.00 pu) serve
    directly as the model's Pref.
  * Pre-fault: all published line data, VSG terminal-voltage set points
    |V| = published (1.03/1.01 pu), P spec'd for VSG 2..4 with VSG 1 as the
    loss-balancing slack (its P lands within ~0.1 pu of 7.0). This reproduces
    the published operating point to ~1e-2 rad.
  * Post-fault: one of the two circuits 8-9 is tripped. With the published set
    points the ~3.9 pu inter-area transfer would exceed the transfer limit of
    the remaining corridor - exactly the situation the paper resolves by
    "necessary adjustments ... to the power and inner-loop set points of the
    VSGs to render a post-fault equilibrium with nominal frequency possible".
    We re-dispatch symmetrically within each area to an inter-area transfer of
    2.0 pu, with area losses fixed by a short fixed-point iteration. The
    resulting set-point vector [g1, g1, g2, g2] is the swing model's Pref and
    the solved EMF angles DELTA_POST are the model's equilibrium delta*, so
    x = 0 is an exact post-fault equilibrium.
  * |E_i| is frozen at the pre-fault solved values for all post-fault solving.
"""
import numpy as np

# ------------------------------------------------------------------ parameters
SB = 100.0          # MVA
UB = 230.0          # kV
ZB = UB**2 / SB     # 529 ohm
WB = 2 * np.pi * 60.0   # 376.9911 rad/s

N_VSG = 4
N = 7               # states: 3 relative angles + 4 speed deviations
H_VIR = 4.0         # virtual inertia per paper
SRATED = 900.0      # MVA rating of the generators the VSGs replace
M_PU = 2 * H_VIR * SRATED / SB         # = 72 pu*s with speed in pu (dδ/dt = WB(ω-1)); see REPORT.md
D_PU = 5.0 * SRATED / SB   # 5 pu on the 900 MVA VSG base = 45 pu on the 100 MVA system base
XV = 0.3            # virtual impedance jXV, pu
DT = 0.5e-3         # sampling / control interval, s (paper)

# Region of interest for training data and verification (paper Section V-B)
DW_LIM = 0.1
DD_LIM = 2 * np.pi

# loads at 1-based Kundur buses 7 and 9 (0-based nodes 6 and 8): P pu, Q pu.
# 200 Mvar capacitor banks are folded at each load bus (defensible assumption;
# see NOTES.md). The fold magnitudes are iterated to the solved |V| so the
# folded constant-Z loads consume exactly the published flat powers.
LOAD = {6: (9.67, 1.00), 8: (17.67, 1.00)}
LOAD_V = {6: 0.9610114, 8: 0.9713754}          # |V| used to fold (iterated)
SHUNT_B = {6: 2.0 / LOAD_V[6]**2, 8: 2.0 / LOAD_V[8]**2}   # 200 Mvar caps, pu
FAULT_Z = 0.001                                # three-phase fault at ties in B8

# VSG terminal voltage set points (published 1-based buses: 1.03/1.01/1.03/1.01)
V_SET = np.array([1.03, 1.01, 1.03, 1.01])
P_REF0 = np.array([7.00, 7.00, 7.19, 7.00])    # pu, published power set points

# branches: (from, to, R ohm, X ohm, B uS), 1-based Kundur numbering minus 1
LINES = [
    (4, 5, 1.3225, 13.225, 41.352),   # bus 5-6
    (10, 9, 1.3225, 13.225, 41.352),  # bus 11-10
    (5, 6, 0.529, 5.29, 16.541),      # bus 6-7
    (9, 8, 0.529, 5.29, 16.541),      # bus 10-9
    (6, 7, 5.819, 58.19, 181.947),    # bus 7-8 ckt 1
    (6, 7, 5.819, 58.19, 181.947),    # bus 7-8 ckt 2
    (8, 7, 5.819, 58.19, 181.947),    # bus 9-8 ckt 1
    (8, 7, 5.819, 58.19, 181.947),    # bus 9-8 ckt 2
]
# step-up transformers: (internal VSG bus k, HV bus node, X pu on 900 MVA)
TRANSFO = [(0, 4, 0.15), (1, 5, 0.15), (2, 10, 0.15), (3, 9, 0.15)]
XB_T = 0.15 * SB / SRATED      # = j0.016667 pu on 100 MVA

NB = 11                        # network buses 0..10
EMF_NODES = [NB + k for k in range(N_VSG)]     # 11..14
REF_NODE = EMF_NODES[0]        # angle reference = VSG 1 EMF
YV = 1.0 / (1j * XV)           # admittance of the virtual impedance


def zpu(r_ohm, x_ohm, b_us):
    """line pu impedance/admittance on 100 MVA, 230 kV."""
    return r_ohm / ZB, x_ohm / ZB, b_us * 1e-6 * ZB


# ------------------------------------------------------------------- Y-bus
def build_y(topo="pre"):
    """Full 15x15 Y-bus including the EMF nodes behind jXV.

    topologies:
      'pre'   : all 8 line circuits in service
      'post'  : exactly one of the two 8-9 circuits open
      'fault' : all circuits in + a small ground shunt at the faulted bus
    Loads and shunts are folded as constant admittance (const-Z loads).
    """
    Y = np.zeros((NB + 4, NB + 4), complex)
    for li, (i, j, r, x, b) in enumerate(LINES):
        if topo == "post" and li == 6:
            continue  # drop exactly one of the two 9-8 tie circuits (idx 6)
        rp, xp, bp = zpu(r, x, b)
        y = 1.0 / complex(rp, xp)
        Y[i, i] += y + 1j * bp / 2
        Y[j, j] += y + 1j * bp / 2
        Y[i, j] -= y
        Y[j, i] -= y
    for (g, t, _xpu9) in TRANSFO:
        y = 1.0 / (1j * XB_T)
        Y[g, g] += y
        Y[t, t] += y
        Y[g, t] -= y
        Y[t, g] -= y
    for bus, (p, q) in LOAD.items():
        v = LOAD_V[bus]
        Y[bus, bus] += np.conj(complex(p, q)) / v**2 + 1j * SHUNT_B[bus]
    if topo == "fault":
        Y[7, 7] += 1.0 / FAULT_Z          # solid fault at the B8 tie centre
    for k in range(4):
        bus, emf = k, EMF_NODES[k]
        Y[bus, bus] += YV
        Y[emf, emf] += YV
        Y[bus, emf] -= YV
        Y[emf, bus] -= YV
    return Y


def kron_reduce(Y, keep):
    """Kron reduction of Y (square complex) onto nodes `keep`."""
    keep = list(keep)
    other = [k for k in range(Y.shape[0]) if k not in keep]
    Ykk = Y[np.ix_(keep, keep)]
    Ykr = Y[np.ix_(keep, other)]
    Yrr = Y[np.ix_(other, other)]
    return Ykk - Ykr @ np.linalg.solve(Yrr, Ykr.T)


def reduced_y(topo="pre"):
    """Reduced 4x4 admittance among the VSG EMF nodes for a topology."""
    return kron_reduce(build_y(topo), EMF_NODES)


def pe_of_delta(Yr, delta_a, delta_b=None):
    """Electrical power at the EMF nodes, vectorized.

    Pe_i = Re{ E_i e^{j d_i} * conj(I_i) },  I = Yr @ (E e^{j d}), with the
    fixed magnitudes E_i (paper Section II-A closed form). delta_a: (..., 4)
    absolute angles (rad); returns (..., 4) pu powers.
    """
    X = E_MAG * np.exp(1j * delta_a)
    I = np.einsum("ij,...j->...i", Yr, X)
    return np.real(X * np.conj(I))


# --------------------------------------------------------------- power flow
def pf_solve(topo, p_targets, emf_mag_fixed=None, z0=None):
    """Full AC power flow on the 15-node network.

    p_targets: length-4 pu P injections matched at the EMF nodes
      (P_e = Re{E conj(I)}); an entry of None = free (slack), the reference.
    emf_mag_fixed: length-4 with entries either a fixed magnitude or None
      (solved). None for the whole list means all four are solved (pre-fault);
      in that case terminal voltage-magnitude set points also apply, because
      with frozen EMFs no regulation authority remains and |V| floats.
    Returns (V_complex, pe_vector, residual_norm, ang, mag)."""
    Y = build_y(topo)

    def unpack(z):
        # layout: 14 angles (all nodes except REF_NODE) + free magnitudes
        # (network nodes, then any EMF node whose fixed entry is None).
        ang = np.empty(15)
        pos = 0
        for k in range(15):
            if k == REF_NODE:
                ang[k] = 0.0
            else:
                ang[k] = z[pos]
                pos += 1
        if emf_mag_fixed is None:
            mag = z[pos:pos + 15].copy()
        else:
            mag = np.empty(15)
            mag[:NB] = z[pos:pos + NB]
            pos += NB
            for i in range(4):
                mag[NB + i] = z[pos] if emf_mag_fixed[i] is None else float(emf_mag_fixed[i])
                pos += 1 if emf_mag_fixed[i] is None else 0
        return ang, mag

    def residual(z):
        ang, mag = unpack(z)
        V = mag * np.exp(1j * ang)
        out = []
        # network nodes 0..10: net Kirchhoff current must be zero (all loads
        # folded into Y): Re/Im{(YV)_k} = 0. Scale by ~the largest realistic
        # branch current (Y entries reach ~60 pu) so all residuals are O(1).
        YVn = Y @ V
        for k in range(NB):
            out.append(YVn[k].real / 30.0)
            out.append(YVn[k].imag / 30.0)
        # EMF nodes: matched P injections (pe = Re{E conj(I_net)}), except the
        # reference node when its target is None (slack).
        for i in range(4):
            t = p_targets[i]
            if t is None:
                continue
            k = EMF_NODES[i]
            I_out = YV * (V[k] - V[i])
            pe = (V[k] * np.conj(I_out)).real
            out.append((pe - t) / 7.0)
        # terminal voltage magnitude set points (pre-fault regulation only)
        if emf_mag_fixed is None:
            for i in range(4):
                out.append(mag[i] - V_SET[i])
        return np.array(out)

    n_ang = 14
    n_mag_free = NB if emf_mag_fixed is not None else 15
    nvar = n_ang + n_mag_free

    if z0 is None:
        ang0 = np.zeros(15)
        ang0[4] = -0.17
        ang0[5] = -0.22
        ang0[9] = -0.47
        ang0[10] = -0.65
        mag0 = np.ones(15)
        mag0[:4] = 1.03
        mag0[NB:] = 2.0
        if emf_mag_fixed is None:
            z0 = np.concatenate([np.delete(ang0, REF_NODE), mag0])
        else:
            emf0 = [E_MAG[i] for i in range(4) if emf_mag_fixed[i] is None]
            z0 = np.concatenate([np.delete(ang0, REF_NODE), mag0[:NB], emf0])
    from scipy.optimize import least_squares
    sol = least_squares(residual, z0, method="lm", xtol=1e-12, ftol=1e-12,
                        gtol=1e-12, max_nfev=4000)
    ang, mag = unpack(sol.x)
    V = mag * np.exp(1j * ang)
    pe = np.empty(4)
    I_out = np.empty(4, complex)
    for i in range(4):
        I_out[i] = YV * (V[NB + i] - V[i])
        pe[i] = (V[NB + i] * np.conj(I_out[i])).real
    return dict(V=V, pe=pe, rnorm=float(np.linalg.norm(sol.fun)),
                ang=ang, mag=mag, emf=V[NB:], info=sol)


# -------------------------------------------------------- pre-fault operating point
def tie_power(V):
    """Real power transfer over the inter-area ties (the two 6-7 circuits
    between 1-based buses 7 and 8), pu."""
    t = 0.0
    for (a, b, r_, x_, b_) in LINES[4:6]:
        rp_, xp_, _bp = zpu(r_, x_, b_)
        t += (V[a] * np.conj((1.0 / complex(rp_, xp_)) * (V[a] - V[b]))).real
    return t


def solve_pre():
    """Pre-fault operating point: published Ps for VSG2..4, VSG1 as slack.
    The constant-Z load fold magnitudes LOAD_V are iterated to the solved bus
    voltages so the folded loads consume exactly the published flat powers."""
    targets = [None, P_REF0[1], P_REF0[2], P_REF0[3]]
    sol = None
    for _ in range(8):
        LOAD_V[6] = 0.9610114
        LOAD_V[8] = 0.9713754
        SHUNT_B[6] = 2.0 / LOAD_V[6]**2
        SHUNT_B[8] = 2.0 / LOAD_V[8]**2
        sol = pf_solve("pre", targets)
        if sol["rnorm"] > 1e-4:
            raise RuntimeError(f"pre-fault pf did not converge: rnorm={sol['rnorm']:.2e}")
        v6n, v8n = abs(sol["V"][6]), abs(sol["V"][8])
        if abs(v6n - LOAD_V[6]) < 1e-4 and abs(v8n - LOAD_V[8]) < 1e-4:
            LOAD_V[6], LOAD_V[8] = v6n, v8n
            SHUNT_B[6] = 2.0 / v6n**2
            SHUNT_B[8] = 2.0 / v8n**2
            break
        LOAD_V[6], LOAD_V[8] = v6n, v8n
        SHUNT_B[6] = 2.0 / v6n**2
        SHUNT_B[8] = 2.0 / v8n**2
    # one final solve at the frozen fold voltages
    sol = pf_solve("pre", targets)
    if sol["rnorm"] > 1e-4:
        raise RuntimeError(f"pre-fault pf did not converge: rnorm={sol['rnorm']:.2e}")
    return sol


_PRE = solve_pre()
E_MAG = _PRE["mag"][NB:]                       # frozen virtual EMF magnitudes
DELTA_PRE = _PRE["ang"][NB:]                   # pre-fault EMF absolute angles
V_PRE = _PRE["V"]
P_PRE = _PRE["pe"]                             # exact pre-fault Pref (VSG1 = slack)

# ------------------------------------------------------------------ post-fault
def _post_for(targets, z0=None):
    mag4 = E_MAG.copy()
    return pf_solve("post", list(targets), emf_mag_fixed=mag4, z0=z0)


def folded_load_pq(V):
    """Actual P, Q consumed by the folded constant-Z loads given solved bus
    voltages: P = P_nom * (|V| / v_fold)^2."""
    p6 = LOAD[6][0] * (abs(V[6]) / LOAD_V[6])**2
    q6 = LOAD[6][1] * (abs(V[6]) / LOAD_V[6])**2
    p8 = LOAD[8][0] * (abs(V[8]) / LOAD_V[8])**2
    q8 = LOAD[8][1] * (abs(V[8]) / LOAD_V[8])**2
    return p6, q6, p8, q8


def post_pref(transfer_target=None):
    """Post-fault equilibrium (one B8-B9 circuit open).

    Pref of VSG2..4 stay at the published set points; VSG1 is the slack and its
    Pref is set to the solved post-fault value (NOTES.md: "keep Pref_2..4 fixed,
    solve the post-fault network equilibrium from the three remaining equations,
    and set Pref_1 to the resolved value"). With pref = solved pe, x = 0 is an
    exact equilibrium of the swing model at nominal frequency.
    (The earlier symmetric re-dispatch loop corrected the tie flow with the wrong
    sign and diverged; it is kept in kundur_orig.py for reference.)
    Returns (delta_star_abs, pref, sol)."""
    # continuation from a reduced dispatch (6.5, 7.0, 7.0), which solves from the
    # default guess, toward the published set points; keep the last exact solve.
    start = np.array([6.5, 7.0, 7.0])
    goal = np.array([P_REF0[1], P_REF0[2], P_REF0[3]])
    sol, z, frac = None, None, 0.0
    for a in np.linspace(0.0, 1.0, 21):
        t = start + a * (goal - start)
        cand = _post_for([None, *t], z0=z)
        if abs(cand["rnorm"]) > 1e-8:
            break
        sol, z, frac = cand, cand["info"].x, a
    if sol is None:
        raise RuntimeError("post-fault pf did not converge even at the reduced dispatch")
    if frac < 1.0:
        print(f"post_pref: published set points not reachable with frozen EMFs; using {frac:.2f} of the way from (6.5,7,7)")
    pref = sol["pe"].copy()
    print(f"post_pref: Pref = {np.round(pref, 4)} pu (VSG1 slack), tie {tie_power(sol['V']):.4f} pu")
    return np.angle(sol["emf"]), pref, sol


# ---------------------------------------------------------- one discrete step
def f_one_step_np(x_abs, u, Yr, pref, dt=DT, nsub=4):
    """One zero-order-hold control step from absolute states.

    x_abs: ... x 4 (angles) + ... x 4 (dw) concatenated; returns same layout.
    RK4 with nsub substeps inside the hold interval. Vectorized over leading dim.
    """
    dx = np.concatenate([x_abs[..., :4], x_abs[..., 4:]], axis=-1)
    dt_sub = dt / nsub
    d = dx[..., :4]
    w1 = dx[..., 4:]  # absolute speed in pu (abs layout carries omega, not omega-1)
    dnew, wnew = d.copy(), w1.copy()
    for _ in range(nsub):
        k1d = WB * (wnew - 1.0)
        k1w = (pref - pe_of_delta(Yr, dnew) - D_PU * (wnew - 1.0) + u) / M_PU
        d2 = dnew + 0.5 * dt_sub * k1d
        w2 = wnew + 0.5 * dt_sub * k1w
        k2d = WB * (w2 - 1.0)
        k2w = (pref - pe_of_delta(Yr, d2) - D_PU * (w2 - 1.0) + u) / M_PU
        d3 = dnew + 0.5 * dt_sub * k2d
        w3 = wnew + 0.5 * dt_sub * k2w
        k3d = WB * (w3 - 1.0)
        k3w = (pref - pe_of_delta(Yr, d3) - D_PU * (w3 - 1.0) + u) / M_PU
        d4 = dnew + dt_sub * k3d
        w4 = wnew + dt_sub * k3w
        k4d = WB * (w4 - 1.0)
        k4w = (pref - pe_of_delta(Yr, d4) - D_PU * (w4 - 1.0) + u) / M_PU
        dnew = dnew + dt_sub / 6.0 * (k1d + 2 * k2d + 2 * k3d + k4d)
        wnew = wnew + dt_sub / 6.0 * (k1w + 2 * k2w + 2 * k3w + k4w)
    return np.concatenate([dnew, wnew], axis=-1)


def in_region(x):
    """paper's region: ||ddelta||_inf <= 2 pi and ||dw||_inf <= 0.1."""
    return (np.abs(x[..., :3]).max(axis=-1) <= DD_LIM) & \
           (np.abs(x[..., 3:]).max(axis=-1) <= DW_LIM)


def x_from_abs(x_abs, delta_star):
    """Absolute state -> paper's relative state (n=7 with angle 1 dropped)."""
    return np.concatenate([x_abs[..., 1:4] - delta_star[1:], x_abs[..., 4:] - 1.0], axis=-1)


def abs_from_x(x, delta_star):
    """Paper's relative state -> absolute state."""
    drel = x[..., :3]
    d_abs = np.concatenate([np.zeros_like(drel[..., :1]), drel], axis=-1) + delta_star
    return np.concatenate([d_abs, x[..., 3:] + 1.0], axis=-1)


# --------------------------------------------------------------- data set gen
def gen_dataset(n_traj=2500, length_s=1.0, u_max=0.3, seed=0, stride=10):
    """Random post-fault trajectories with uniformly sampled u (paper recipe).

    Start states uniform inside the filtered region X. Tuples (x_k, x_k+1, u_k)
    kept when both ends lie inside X. `stride` subsamples tuple indices.
    Returns Nx21 float32 array [x, x_next, u].
    """
    Yr = reduced_y("post")
    d_star, pref, _ = post_pref()
    rng = np.random.default_rng(seed)
    g = np.random.default_rng(seed + 1)
    X0 = np.empty((n_traj, N))
    X0[:, :3] = rng.uniform(-DD_LIM, DD_LIM, (n_traj, 3))
    X0[:, 3:] = rng.uniform(-DW_LIM, DW_LIM, (n_traj, 4))
    n_steps = int(round(length_s / DT))
    out = []
    x_abs = abs_from_x(X0, d_star)
    for k in range(n_steps):
        u = g.uniform(-u_max, u_max, (n_traj, 4))
        xn_abs = f_one_step_np(x_abs, u, Yr, pref)
        xn = x_from_abs(xn_abs, d_star)
        xk = x_from_abs(x_abs, d_star)
        inbox = in_region(xk) & in_region(xn)
        if (k % stride) == 0 and inbox.any():
            out.append(np.concatenate([xk[inbox], xn[inbox], u[inbox]], axis=1))
        x_abs = xn_abs
    D = np.concatenate(out, axis=0).astype(np.float32)
    return D, d_star, pref


# ---------------------------------------------------------- fault test scenario
def fault_scenario(controller=None, T=4.0, dt=DT, seed=0):
    """Replicates the paper's Fig. 6 test: fault near B8 at 0.2 s, cleared at
    0.32 s by tripping one 8-9 circuit, then post-fault operation either with
    u = 0 (no control) or with the learned controller (ZOH at dt).
    Returns time axis and arrays of (delta_rel, dw)."""
    Yr_post = reduced_y("post")
    d_star, pref, _ = post_pref()
    Yr_pre = reduced_y("pre")
    Yr_flt = reduced_y("fault")
    x_abs = np.concatenate([DELTA_PRE, np.ones(4)])
    n = int(T / dt)
    ts = np.arange(n) * dt
    hist = np.empty((n, N))
    for k in range(n):
        t = ts[k]
        if t < 0.2:
            Yr, pf = Yr_pre, P_PRE
        elif t < 0.32:
            Yr, pf = Yr_flt, P_PRE
        else:
            Yr, pf = Yr_post, pref
        x = x_from_abs(x_abs, DELTA_PRE if t < 0.2 else d_star)
        hist[k] = x
        if t < 0.32:
            u = np.zeros(4)
        elif controller is None:
            u = np.zeros(4)
        else:
            u = controller(x)
        x_abs = f_one_step_np(x_abs[None], u, Yr, pf)[0]
    return ts, hist
